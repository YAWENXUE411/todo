const Colors = {
  primary: '#1890ff',
  second: '#bae7ff',
  white: '#ffffff',
  yellow: "#ffd700",
  textColor: '#666666',
  grey: "#999",
  // 
  purple: "#483d8b",
  mediumPurple: "#7668ba",
  lightPurple: "#8e8bc4",
  yellow: "#ffd700",
  DarkBlue: "#00008B",
  SlateBlue: "#6A5ACD",
  bgPurple: 'rgb(153,150,221)'
};

export default Colors;