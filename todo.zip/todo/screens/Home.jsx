import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  TextInput,
  Button,
  Image,
  ScrollView,
  Modal,
} from "react-native";
import { Camera } from "expo-camera";
import * as Location from "expo-location";
import { Entypo } from "@expo/vector-icons";
import { AntDesign } from "@expo/vector-icons";
import * as SMS from "expo-sms";
import { storage } from "../firebase/firebase-setup";
import { ref, uploadBytes } from "firebase/storage";
import { writeToTasks, getTasks, update, deleteTask } from "../firebase/firestore";
import moment from "moment";

export default function Home() {
  const [modalVisible, setModalVisible] = useState(false);
  const [datas, setDatas] = useState([]);
  const [cacheData, setCacheData] = useState([]);
  const [title, setTitle] = useState("");
  const [phone, setPhone] = useState("");
  const [curOpt, setCurOpt] = useState("ADD");
  const [curItem, setCurItem] = useState(null);
  const [showCamera, setShowCamera] = useState(false);
  const typeList = ["All", "Active", "Completed"];
  const [curType, setCurType] = useState(typeList[0]);
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [hasCameraPermission, setHasCameraPermission] = useState(null);
  const [hasAudioPermission, setHasAudioPermission] = useState(null);
  const cameraRef = useRef(null);
  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setErrorMsg("Permission to access location was denied");
        return;
      }
      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
    })();
  }, []);

  const getImageBlob = async (uri) => {
    try {
      const response = await fetch(uri);
      const blob = await response.blob();
      return blob;
    } catch (err) {
      console.log("fetch image ", err);
    }
  };

  useEffect(() => {
    (async () => {
      const { status: cameraStatus } =
        await Camera.requestCameraPermissionsAsync();
      setHasCameraPermission(cameraStatus === "granted");
      const { status: audioStatus } =
        await Camera.requestMicrophonePermissionsAsync();
      setHasAudioPermission(audioStatus === "granted");
    })();
    return () => {};
  }, []);

  let text = "Waiting..";
  if (errorMsg) {
    text = errorMsg;
  } else if (location) {
    // console.log("location = ", location)
    text = `${location.coords.latitude},${location.coords.longitude}`;
  }
  const [photoUri, setPhotoUri] = useState(null);
  const takePicture = async () => {
    if (cameraRef) {
      const photo = await cameraRef.current.takePictureAsync();
      setPhotoUri(photo.uri);
      setShowCamera(false);
    }
  };
  const handleOpenSms = (item) => {
    setPhone("");
    setCurItem(item);
    setModalVisible(true);
  };
  const handleOpenEdit = (item) => {
    setCurItem(item);
    setCurOpt("EDIT");
    setTitle(item.title);
    setPhotoUri(
      `https://firebasestorage.googleapis.com/v0/b/video-f9152.appspot.com/o/${item.photoUri}?alt=media&token=7204f0c6-c46a-417e-8595-f0b0c596b760`
    );
  };
  const handleSendSMS = async () => {
    if (!phone) {
      Alert.alert("Phone number can not be empty!");
      return;
    }
    const isAvailable = await SMS.isAvailableAsync();
    if (isAvailable) {
      // do your SMS stuff here
      await SMS.sendSMSAsync(
        [phone],
        `Your task ${curItem.title}, at location ${curItem.location}`
      );
    } else {
      Alert.alert("there's no SMS available on this device");
    }
  };

  const getData = async () => {
    try {
      let res = await getTasks();
      console.log("list data = ", res);
      setCacheData(res);
      setDatas(res);
    } catch (error) {}
  };

  useEffect(() => {
    getData();
  }, []);

  const handleDelete = async (item) => {
    await deleteTask(item.id);
    getData();
    Alert.alert("Successfully Delete!");
  };

  const handleComplete = async (item) => {
    await update(item.id, {
      status: "Completed",
    });
    getData();
    Alert.alert("Successfully Complete!");
  };

  const handleSubmit = async () => {
    if (!title) {
      Alert.alert("Task Title can not be empty!");
      return;
    }
    if (!photoUri) {
      Alert.alert("TPlease take a photo!");
      return;
    }
    if (curOpt == "ADD") {
      let imgBlob = await getImageBlob(photoUri);
      let uuid = moment().valueOf();
      let img_name = `${uuid}_image`;
      const storageRef = ref(storage, img_name);
      uploadBytes(storageRef, imgBlob)
        .then(async (snapshot) => {
          await writeToTasks({
            title,
            photoUri: img_name,
            status: "Active",
            location: text,
          });
          getData();
          setTitle("");
          setPhotoUri("");
          Alert.alert("Successfully Add!");
        })
        .catch((err) => {
          console.log("err = ", err);
        });
    } else {
      if (photoUri.indexOf("https") !== -1) {
        await update(curItem.id, {
          title,
          photoUri: curItem.photoUri,
          status: curItem.status,
          location: text,
        });
        getData();
        setTitle("");
        setPhotoUri("");
        setCurOpt("ADD");
        Alert.alert("Successfully Edit!");
      } else {
        let imgBlob = await getImageBlob(photoUri);
        let uuid = moment().valueOf();
        let img_name = `${uuid}_image`;
        const storageRef = ref(storage, img_name);
        uploadBytes(storageRef, imgBlob)
          .then(async (snapshot) => {
            await update(curItem.id, {
              title,
              photoUri: img_name,
              status: curItem.status,
              location: text,
            });
            getData();
            setTitle("");
            setPhotoUri("");
            setCurOpt("ADD");
            Alert.alert("Successfully Edit!");
          })
          .catch((err) => {
            console.log("err = ", err);
          });
      }
    }
  };

  let remainings = datas.filter((v) => {
    return v.status == "Active";
  });

  // curType
  let filterData = cacheData.filter((v) => {
    let bol;
    if (curType == "All") {
      bol = true;
    } else {
      bol = v.status == curType;
    }
    return bol;
  });

  return (
    <View style={{ flex: 1 }}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,0.3)",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View
            style={{
              backgroundColor: "#fff",
              width: "70%",
              paddingVertical: 20,
            }}
          >
            <View
              style={{
                marginHorizontal: 10,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  marginBottom: 10,
                }}
              >
                Who do you want to send it to?
              </Text>
              <TextInput
                style={{
                  height: 40,
                  borderColor: "gray",
                  borderWidth: 1,
                  width: "100%",
                  paddingHorizontal: 15,
                }}
                onChangeText={(text) => setPhone(text)}
                value={phone}
              />
            </View>
            <TouchableOpacity
              onPress={handleSendSMS}
              style={{
                backgroundColor: "black",
                justifyContent: "center",
                alignItems: "center",
                marginHorizontal: 10,
                paddingVertical: 5,
                marginTop: 20,
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontSize: 16,
                }}
              >
                Send
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                setModalVisible(false);
              }}
              style={{
                backgroundColor: "red",
                justifyContent: "center",
                alignItems: "center",
                marginHorizontal: 10,
                paddingVertical: 5,
                marginTop: 10,
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontSize: 16,
                }}
              >
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      <View
        style={{
          flex: 1,
          position: "absolute",
          zIndex: showCamera ? 10 : -10,
          width: "100%",
          height: "100%",
          backgroundColor: "red",
        }}
      >
        <Camera
          style={{ height: "100%" }}
          type={Camera.Constants.Type.back}
          ref={cameraRef}
        >
          <View
            style={{
              flex: 1,
              backgroundColor: "transparent",
              justifyContent: "flex-end",
            }}
          >
            <Button title="Take A Picture" onPress={takePicture} />
          </View>
        </Camera>
      </View>
      <ScrollView style={{ flex: 1, backgroundColor: "#fff" }}>
        <View
          style={{
            paddingTop: 50,
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Text
            style={{
              fontSize: 25,
              fontWeight: "bold",
            }}
          >
            TodoMatic
          </Text>
        </View>
        <View
          style={{
            marginHorizontal: 10,
            marginTop: 20,
            alignItems: "center",
          }}
        >
          <Text
            style={{
              marginBottom: 10,
            }}
          >
            What needs to be done?
          </Text>
          <TextInput
            style={{
              height: 40,
              borderColor: "gray",
              borderWidth: 1,
              width: "100%",
              paddingHorizontal: 15,
            }}
            onChangeText={(text) => setTitle(text)}
            value={title}
          />
          <View
            style={{
              flexDirection: "row",
              marginTop: 10,
              justifyContent: "space-between",
            }}
          >
            <TouchableOpacity
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
              onPress={() => {
                setShowCamera(true);
              }}
            >
              <AntDesign name="camera" size={50} color="#666" />
              {photoUri && (
                <Image
                  source={{ uri: photoUri }}
                  style={{
                    width: 50,
                    height: 50,
                    borderWidth: 1,
                    borderColor: "#ddd",
                    marginLeft: 10,
                  }}
                />
              )}
            </TouchableOpacity>

            <View
              style={{
                // flex: 1,
                // marginLeft: 15,
                flex: 1,
                justifyContent: "flex-end",
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <Entypo name="location-pin" size={24} color="#666" />
              <Text
                style={{
                  color: "#666",
                  marginLeft: 5,
                }}
              >
                {text}
              </Text>
            </View>
          </View>
        </View>
        <TouchableOpacity
          onPress={handleSubmit}
          style={{
            backgroundColor: "black",
            justifyContent: "center",
            alignItems: "center",
            marginHorizontal: 10,
            paddingVertical: 10,
            marginTop: 10,
          }}
        >
          <Text
            style={{
              color: "#fff",
              fontSize: 18,
            }}
          >
            {curOpt == "ADD" ? "Add" : "Edit"}
          </Text>
        </TouchableOpacity>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            marginHorizontal: 10,
            marginTop: 20,
          }}
        >
          {typeList.map((v) => {
            return (
              <TouchableOpacity
                key={v}
                onPress={() => {
                  setCurType(v);
                }}
                style={{
                  borderWidth: 1,
                  borderLeftWidth: v == "Active" ? 0 : 1,
                  borderRightWidth: v == "Active" ? 0 : 1,
                  flex: 1,
                  borderColor: "#ddd",
                  justifyContent: "center",
                  alignItems: "center",
                  paddingVertical: 5,
                  backgroundColor: v == curType ? "black" : "#fff",
                }}
              >
                <Text
                  style={{
                    color: v == curType ? "#fff" : "#666",
                    fontSize: 16,
                  }}
                >
                  {v}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
        <View
          style={{
            flexDirection: "row",
            marginHorizontal: 10,
            marginTop: 20,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "bold",
            }}
          >
            {remainings.length} tasks remaining
          </Text>
        </View>
        {filterData.length === 0 && (
          <View
            style={{
              flexDirection: "row",
              marginHorizontal: 10,
              justifyContent: "center",
              marginTop: 20,
            }}
          >
            <Text
              style={{
                fontSize: 16,
                color: "#999",
              }}
            >
              no tasks ~
            </Text>
          </View>
        )}
        <View
          style={{
            marginHorizontal: 10,
            marginTop: 20,
          }}
        >
          {filterData.map((item, index) => {
            return (
              <View
                key={index}
                style={{
                  flex: 1,
                  flexDirection: "row",
                  justifyContent: "space-between",
                  marginBottom: 20,
                }}
              >
                <Image
                  style={{
                    width: 80,
                    height: 80,
                    borderWidth: 1,
                    borderColor: "#ddd",
                  }}
                  source={{
                    uri: `https://firebasestorage.googleapis.com/v0/b/video-f9152.appspot.com/o/${item.photoUri}?alt=media&token=7204f0c6-c46a-417e-8595-f0b0c596b760`,
                  }}
                />
                <View
                  style={{
                    // flex: 1,
                    marginLeft: 15,
                    flex: 1,
                    justifyContent: "space-between",
                  }}
                >
                  <View>
                    <Text
                      style={{
                        fontWeight: "bold",
                        fontSize: 16,
                      }}
                    >
                      {item.title}
                    </Text>
                    <View
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        marginTop: 5,
                      }}
                    >
                      <Entypo name="location-pin" size={24} color="#666" />
                      <Text
                        style={{
                          color: "#666",
                          marginLeft: 5,
                        }}
                      >
                        {item.location}
                      </Text>
                    </View>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginTop: 5,
                    }}
                  >
                    <TouchableOpacity
                      onPress={() => {
                        handleOpenEdit(item);
                      }}
                      style={{
                        backgroundColor: "#3c9cff",
                        justifyContent: "center",
                        alignItems: "center",
                        paddingVertical: 3,
                        flex: 1,
                      }}
                    >
                      <Text
                        style={{
                          color: "#fff",
                          fontSize: 12,
                        }}
                      >
                        Edit
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        handleDelete(item);
                      }}
                      style={{
                        backgroundColor: "#f56c6c",
                        justifyContent: "center",
                        alignItems: "center",
                        paddingVertical: 3,
                        flex: 1,
                      }}
                    >
                      <Text
                        style={{
                          color: "#fff",
                          fontSize: 12,
                        }}
                      >
                        Delete
                      </Text>
                    </TouchableOpacity>
                    {item.status !== "Completed" && (
                      <TouchableOpacity
                        onPress={() => {
                          handleComplete(item);
                        }}
                        style={{
                          backgroundColor: "#5ac725",
                          justifyContent: "center",
                          alignItems: "center",
                          paddingVertical: 3,
                          flex: 1,
                        }}
                      >
                        <Text
                          style={{
                            color: "#fff",
                            fontSize: 12,
                          }}
                        >
                          Complete
                        </Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity
                      onPress={() => {
                        handleOpenSms(item);
                      }}
                      style={{
                        backgroundColor: "black",
                        justifyContent: "center",
                        alignItems: "center",
                        paddingVertical: 3,
                        flex: 1,
                      }}
                    >
                      <Text
                        style={{
                          color: "#fff",
                          fontSize: 12,
                        }}
                      >
                        SMS
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}
