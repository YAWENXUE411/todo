import {
  collection,
  addDoc,
  doc,
  deleteDoc,
  updateDoc,
  getDoc,
  getDocs,
  query
} from "firebase/firestore";
import {
  firestore
} from "./firebase-setup";

export async function getTasks() {
  try {
    let data = [];
    const collectionTasks = collection(firestore, "tasks");
    const q = query(collectionTasks);
    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) {
      return data;
    }
    querySnapshot.forEach((doc) => {
      data.push({
        ...doc.data(),
        id: doc.id
      });
    });
    return data;
  } catch (err) {
    console.log(err);
  }
}

export async function writeToTasks(data) {
  try {
    await addDoc(collection(firestore, "tasks"), data);
  } catch (err) {
    console.log(err);
  }
}

export async function update(key, obj) {
  try {
    const docRef = doc(firestore, "tasks", key);
    await updateDoc(docRef, obj);
  } catch (err) {
    console.log(err);
  }
}

export async function deleteTask(key) {
  try {
    const docRef = doc(firestore, "tasks", key);
    await deleteDoc(docRef);
  } catch (err) {
    console.log(err);
  }
}